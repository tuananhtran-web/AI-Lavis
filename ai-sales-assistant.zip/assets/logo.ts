export const logoUrl = 'https://coating.lavisbrothers.com/wp-content/uploads/2022/08/cropped-coating-white-288x77.png';
