
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, DocumentData, LearnedMappings, Template, GeneratedDocument } from '../types';
import { generateDocumentData, getGeneralResponse } from '../services/geminiService';
import { BotIcon, SendIcon, UserIcon, ResetIcon, UploadIcon, ExternalLinkIcon, PaletteIcon } from './icons';
import { GeneratedDocumentPreview } from './GeneratedDocumentPreview';

interface ChatWindowProps {
    templates: Template[];
    learnedMappings: LearnedMappings;
    onTemplateSelect: (template: Template) => void;
}

const LoadingBubble: React.FC = () => (
    <div className="flex items-start space-x-3">
        <div className="bg-violet-600 rounded-full p-2">
             <BotIcon className="w-6 h-6 text-white"/>
        </div>
        <div className="bg-gray-700 rounded-lg p-3 max-w-lg">
            <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
            </div>
        </div>
    </div>
);

const renderMessageText = (text: string) => {
    // Escape HTML to prevent XSS, except for the tags we are about to add.
    let processedText = text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

    // Remove markdown characters, just in case the model adds them despite instructions.
    processedText = processedText.replace(/[*#_]/g, '');

    // Linkify URLs
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    processedText = processedText.replace(urlRegex, (url) => {
        const cleanedUrl = url.replace(/&amp;/g, '&'); // Fix escaped ampersands in URLs
        if (/\.(jpeg|jpg|gif|png|svg)$/i.test(cleanedUrl)) {
            return `<img src="${cleanedUrl}" alt="Hình ảnh minh họa" class="my-2 rounded-lg max-w-full sm:max-w-xs" />`;
        }
        return `<a href="${cleanedUrl}" target="_blank" rel="noopener noreferrer" class="text-violet-400 hover:underline break-all">${cleanedUrl}</a>`;
    });
    
    // Process newlines
    processedText = processedText.replace(/\n/g, '<br />');

    return processedText;
};


const Message: React.FC<{ message: ChatMessage }> = ({ message }) => {
    const isAssistant = message.role === 'assistant';

    if (isAssistant) {
        return (
            <div className="flex items-start space-x-3">
                <div className="bg-violet-600 rounded-full p-2 flex-shrink-0">
                    <BotIcon className="w-6 h-6 text-white" />
                </div>
                <div className="flex flex-col items-start space-y-2 w-full">
                    {message.text && (
                         <div className="bg-gray-800 rounded-lg p-3 max-w-lg text-white">
                            <p className="text-sm" dangerouslySetInnerHTML={{ __html: renderMessageText(message.text) }}></p>
                         </div>
                    )}
                    {message.sources && message.sources.length > 0 && (
                        <div className="bg-gray-800 border border-gray-700 rounded-lg p-3 max-w-lg w-full">
                            <h4 className="text-xs font-semibold text-gray-400 mb-2">NGUỒN THAM KHẢO</h4>
                            <div className="flex flex-col space-y-2">
                                {message.sources.map((source, index) => (
                                    <a href={source.uri} key={index} target="_blank" rel="noopener noreferrer" className="text-sm text-violet-400 hover:underline flex items-center">
                                        <ExternalLinkIcon className="w-4 h-4 mr-2 flex-shrink-0" />
                                        <span className="truncate">{source.title || source.uri}</span>
                                    </a>
                                ))}
                            </div>
                        </div>
                    )}
                    {message.templateSelection && (
                        <div className="bg-gray-800 rounded-lg p-3 max-w-lg w-full">
                            <p className="text-sm text-gray-300 mb-3">Hoặc anh/chị có thể chọn một mẫu tài liệu có sẵn để bắt đầu:</p>
                            <div className="flex flex-col space-y-2">
                                {message.templateSelection.map(template => (
                                    <div key={template.id} className="flex items-center space-x-2">
                                        <button 
                                            onClick={() => message.onTemplateSelect?.(template)}
                                            className="flex-grow bg-gray-700 border border-violet-500 text-violet-300 font-semibold py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors text-left"
                                        >
                                            {template.name}
                                        </button>
                                        <button title="Đặt lại các trường đã học" className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-full transition-colors" onClick={() => alert('Chức năng đặt lại đang được phát triển!')}>
                                            <ResetIcon className="w-5 h-5"/>
                                        </button>
                                    </div>
                                ))}
                                 <button
                                    onClick={() => alert('Chức năng tải file lên đang được phát triển!')}
                                    className="flex items-center justify-center w-full bg-violet-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-violet-700 transition-colors mt-2"
                                >
                                    <UploadIcon className="w-5 h-5 mr-2" />
                                    Tải Mẫu Mới
                                </button>
                            </div>
                        </div>
                    )}
                    {message.generatedDocument && (
                        <GeneratedDocumentPreview document={message.generatedDocument} />
                    )}
                </div>
            </div>
        );
    }

    return (
        <div className="flex items-start justify-end space-x-3">
            <div className="bg-gray-700 text-white rounded-lg p-3 max-w-lg">
                <p className="text-sm">{message.text}</p>
            </div>
             <div className="bg-gray-800 rounded-full p-2 flex-shrink-0">
                <UserIcon className="w-6 h-6 text-gray-300" />
            </div>
        </div>
    );
};


export const ChatWindow: React.FC<ChatWindowProps> = ({ templates, learnedMappings, onTemplateSelect }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const [selectedTemplateForAutomation, setSelectedTemplateForAutomation] = useState<Template | null>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);
  
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          id: 'initial-prompt',
          role: 'assistant',
          text: "Xin chào, em là Trợ lý AI từ Lavis Brothers Coating. Em có thể tư vấn về các giải pháp sơn hoặc hỗ trợ anh/chị tạo báo giá và tài liệu. Anh/chị cần em giúp gì ạ? 😊",
        },
        {
          id: 'template-selection-prompt',
          role: 'assistant',
          templateSelection: templates,
          onTemplateSelect: (template) => {
            const mappings = learnedMappings[template.id];
            if (mappings && mappings.length > 0) {
              setMessages(prev => [...prev, {
                id: `selection-${template.id}`,
                role: 'user',
                text: `Em dùng mẫu: ${template.name}`
              },{
                id: `prompt-info-${template.id}`,
                role: 'assistant',
                text: `Dạ tuyệt vời! Em thấy mình đã dùng mẫu "${template.name}" trước đây. Anh/chị vui lòng cung cấp thông tin mới cho các mục đã chỉnh sửa, em sẽ tự động tạo tài liệu nhé.`
              }]);
              setSelectedTemplateForAutomation(template);
            } else {
               setMessages(prev => [...prev, {
                id: `selection-${template.id}`,
                role: 'user',
                text: `Em dùng mẫu: ${template.name}`
              },{
                id: `start-edit-${template.id}`,
                role: 'assistant',
                text: `Dạ, em sẽ bắt đầu một tài liệu mới với mẫu "${template.name}". Em sẽ mở trình chỉnh sửa để anh/chị điền thông tin. Em sẽ ghi nhớ các mục anh/chị chỉnh sửa cho những lần sau ạ!`
              }]);
              setTimeout(() => onTemplateSelect(template), 1500);
            }
          }
        },
      ]);
    }
  }, [messages.length, templates, learnedMappings, onTemplateSelect]);


  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = { id: Date.now().toString(), role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    if (selectedTemplateForAutomation) {
        // Automation Mode
        const fieldsToExtract = learnedMappings[selectedTemplateForAutomation.id];
        if (!fieldsToExtract) {
            setIsLoading(false);
            setMessages(prev => [...prev, {id: 'error', role: 'assistant', text: "Đã xảy ra lỗi: Không tìm thấy các trường đã học cho mẫu này."}]);
            return;
        }

        const responseData = await generateDocumentData(input, fieldsToExtract);

        if (responseData.error) {
            setMessages(prev => [...prev, { id: Date.now().toString(), role: 'assistant', text: responseData.error }]);
        } else {
            const finalDocumentData = {
                ...selectedTemplateForAutomation.initialData,
                ...responseData
            };

            const generatedDocument: GeneratedDocument = {
                template: selectedTemplateForAutomation,
                data: finalDocumentData as DocumentData
            };
            
            setMessages(prev => [...prev, { id: Date.now().toString(), role: 'assistant', generatedDocument }]);
            setSelectedTemplateForAutomation(null);
        }
    } else {
        // General Chat Mode
        const { text, sources } = await getGeneralResponse(input);
        setMessages(prev => [...prev, { id: Date.now().toString(), role: 'assistant', text, sources }]);
    }
    
    setIsLoading(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };
  
  const isAutomationMode = selectedTemplateForAutomation !== null;
  const placeholderText = isAutomationMode 
    ? "Nhập các thông tin mới tại đây..." 
    : "Hỏi em về giải pháp sơn hoặc chọn một mẫu ở trên...";

  return (
    <div className="flex flex-col h-full bg-gray-900 rounded-lg shadow-lg border border-gray-700 max-w-4xl mx-auto">
      <div className="p-4 border-b border-gray-700">
        <h2 className="text-xl font-bold text-gray-200">AI Lavis Brothers Coating</h2>
      </div>
      <div className="flex-grow p-4 sm:p-6 overflow-y-auto space-y-6">
        {messages.map(msg => (
          <Message key={msg.id} message={msg} />
        ))}
        {isLoading && <LoadingBubble />}
        <div ref={chatEndRef} />
      </div>
      <div className="p-4 border-t border-gray-700 bg-gray-900">
        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={placeholderText}
            className="w-full pl-4 pr-12 py-3 bg-gray-800 border border-gray-600 rounded-full focus:outline-none focus:ring-2 focus:ring-violet-500 text-white"
            disabled={isLoading}
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2.5 rounded-full text-white bg-violet-600 hover:bg-violet-700 disabled:bg-violet-400 disabled:cursor-not-allowed transition-colors"
          >
            <SendIcon className="w-5 h-5" />
          </button>
        </div>
        <div className="mt-4 flex justify-center">
            <a
                href="http://36.50.55.10:3000/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-x-2 rounded-md bg-gray-700 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-gray-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-500 transition-colors"
            >
                <PaletteIcon className="w-5 h-5" aria-hidden="true" />
                Phối Màu
            </a>
        </div>
      </div>
    </div>
  );
};
