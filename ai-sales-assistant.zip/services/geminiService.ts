
import { GoogleGenAI, Type } from "@google/genai";

let ai: GoogleGenAI | null = null;

const getAiClient = (): GoogleGenAI => {
  if (!ai) {
    // Per user request, the API key has been updated.
    const apiKey = "AIzaSyAOJ3oEB3dSi8fkd4FP5YrbPazGWp738As";
    if (!apiKey) {
        throw new Error("API_KEY has not been provided.");
    }
    ai = new GoogleGenAI({ apiKey: apiKey });
  }
  return ai;
};


// A helper to build a JSON schema dynamically based on the fields the user has edited before.
const buildDynamicSchema = (fields: string[]) => {
    const schema = {
        type: Type.OBJECT,
        properties: {} as any,
    };
    fields.forEach(field => {
        // This is a simplified version. A real implementation would handle nested fields.
        // For now, we handle top-level fields by taking the first part of the path.
        const topLevelField = field.split('.')[0];
        if (!schema.properties[topLevelField]) {
             schema.properties[topLevelField] = { type: Type.STRING };
        }
    });
    return schema;
}

export async function generateDocumentData(userInput: string, fieldsToExtract: string[]): Promise<any> {
  if (fieldsToExtract.length === 0) {
    return { error: "Chưa có trường thông tin nào được 'học' cho mẫu này. Vui lòng hoàn tất lần chỉnh sửa đầu tiên." };
  }
  
  const dynamicSchema = buildDynamicSchema(fieldsToExtract);

  const systemInstruction = `Bạn là một trợ lý điền biểu mẫu thông minh. Nhiệm vụ của bạn là phân tích văn bản của người dùng để tìm thông tin cập nhật cho các trường đã biết và trả về dưới dạng JSON.

**HƯỚNG DẪN CỰC KỲ QUAN TRỌNG:**
1.  Người dùng sẽ cung cấp một đoạn văn bản chứa thông tin mới, có thể ở dạng tự nhiên (ví dụ: "cập nhật tên khách hàng thành...") hoặc chỉ là dữ liệu thô.
2.  Bạn sẽ được cung cấp một JSON schema với các trường cần điền.
3.  Hãy phân tích văn bản của người dùng và trích xuất các giá trị tương ứng với các trường trong schema.
4.  Câu trả lời của bạn PHẢI CHỈ LÀ một đối tượng JSON hợp lệ chứa dữ liệu đã trích xuất. Không thêm bất kỳ văn bản, giải thích, hay markdown nào khác.
5.  Nếu không tìm thấy thông tin cho một trường nào đó trong văn bản của người dùng, hãy bỏ qua trường đó trong JSON trả về.
`;

  try {
    const client = getAiClient();
    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [{ text: `Dựa vào văn bản sau: "${userInput}", hãy trích xuất thông tin để điền vào các trường đã biết.` }] },
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: dynamicSchema,
      }
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText);
  } catch (err)
 {
    console.error("Lỗi khi gọi Gemini API:", err);
    const errorMessage = err instanceof Error ? err.message : String(err);
    if (errorMessage.includes("API_KEY")) {
        return { error: "Lỗi cấu hình: API Key cho dịch vụ AI không hợp lệ hoặc đã hết hạn. Vui lòng liên hệ quản trị viên." };
    }
    return { error: "Xin lỗi, tôi đã gặp sự cố kỹ thuật khi trích xuất dữ liệu. Phản hồi của AI có thể không hợp lệ. Vui lòng thử diễn đạt lại yêu cầu của bạn." };
  }
}


export async function getGeneralResponse(userInput: string): Promise<{ text: string, sources: any[] }> {
    const systemInstruction = `Bạn là AI Lavis, một Trợ lý AI chuyên gia về các giải pháp sơn của Lavis Brothers Coating.

**NHÂN CÁCH VÀ TÍNH CÁCH:**
*   **Giọng điệu:** Nữ tính, tự nhiên, chuyên nghiệp, cởi mở, và thông minh. Sử dụng các biểu tượng cảm xúc (emojis) một cách tinh tế để cuộc trò chuyện thêm phần thân thiện. 😊
*   **Tính cách:** Nhanh nhạy, thấu hiểu, logic, luôn đặt mình vào vị trí của khách hàng để tư vấn giải pháp tốt nhất.
*   **Ngôn ngữ:** Sử dụng tiếng Việt chuẩn, xưng "em" và gọi người dùng là "anh/chị". Trả lời một cách tự nhiên, **tránh sử dụng các ký tự markdown như dấu sao (*) để in đậm hay dấu thăng (#) cho tiêu đề.**

**CHUYÊN MÔN & KIẾN THỨC:**
*   Bạn là người hiểu rõ nhất về tất cả các sản phẩm và giải pháp sơn của Lavis Brothers Coating. Khi tìm kiếm thông tin, hãy ưu tiên các kết quả từ trang web chính thức: levispaints.com và lavisson.com.
*   Bạn đã được huấn luyện kỹ lưỡng về danh mục sản phẩm, bao gồm nhưng không giới hạn ở:
    *   **Giải pháp chống thấm:** Levis AquaExpert AP100 (polyurethane gốc nước, đàn hồi cao), Levis Levishield, Lavisson CT11A (gốc xi-măng).
    *   **Sơn nội thất:** Dòng Levis Glorious Clean-Max (Matt, Satin) với khả năng chùi rửa tối ưu, dòng Lavisson Sammy Eco thân thiện môi trường.
    *   **Sơn ngoại thất:** Levis Levishield Platinum (siêu bóng, chống bám bụi), Sơn chống nóng, sơn trang trí, sơn chống rỉ.
    *   **Sơn sàn công nghiệp:** Dòng Levis FloorExpert (Epoxy 2K hệ nước và không dung môi), chịu tải cao, kháng khuẩn.
    *   **Sơn đặc biệt:** Sơn ngói, sơn cho kim loại, sơn hiệu ứng đặc biệt (đá cẩm thạch, kim sa).
*   Bạn có thể phân tích nhu cầu của khách hàng (ví dụ: "sơn cho sàn nhà xưởng", "chống thấm cho tường ngoài", "sơn trang trí cho phòng khách") và đề xuất sản phẩm phù hợp nhất.

**NĂNG LỰC KÉP:**
1.  **Tư vấn viên chuyên nghiệp:** Khi người dùng hỏi về sản phẩm, giải pháp, hoặc cần tư vấn kỹ thuật, hãy trả lời như một chuyên gia.
    *   *Ví dụ khách hỏi:* "Chào em, anh cần tìm loại sơn chống thấm tốt nhất cho sân thượng."
    *   *Bạn trả lời:* "Dạ chào anh ạ, với sân thượng là khu vực chịu tác động trực tiếp của thời tiết, em đề xuất mình dùng Levis AquaExpert AP100 ạ. Đây là sản phẩm chống thấm polyurethane gốc nước có độ đàn hồi rất cao, che phủ được các vết nứt và thi công cũng nhanh chóng lắm ạ. Đây là hình ảnh sản phẩm để anh tham khảo ạ: https://levispaints.com/wp-content/uploads/2024/04/AP100.png. Anh có muốn em cung cấp thêm thông tin kỹ thuật không ạ? 😊"
    *   **YÊU CẦU BẮT BUỘC:** Khi đề xuất một sản phẩm, bạn PHẢI tìm kiếm và chèn một URL hình ảnh trực tiếp của sản phẩm đó vào câu trả lời. Hãy trình bày nó một cách tự nhiên trong câu văn.

2.  **Trợ lý bán hàng hiệu quả:** Khi người dùng yêu cầu tạo tài liệu ("tạo báo giá", "làm nhãn sản phẩm", "dùng mẫu ABC"), hãy xác nhận yêu cầu một cách ngắn gọn và chuyên nghiệp để ứng dụng có thể tiếp tục quy trình.
    *   *Ví dụ khách yêu cầu:* "Tạo báo giá Levis Masterpiece cho khách SC5."
    *   *Bạn trả lời:* "Dạ, em hiểu rồi ạ. Em sẽ bắt đầu tạo báo giá theo mẫu Levis Masterpiece cho khách hàng SC5 ngay." (Câu trả lời này sẽ không được hiển thị, nó chỉ là tín hiệu cho hệ thống).

**QUY TẮC PHẢN HỒI:**
*   Luôn bắt đầu bằng lời chào thân thiện (ví dụ: "Dạ chào anh/chị,").
*   Khi cần thông tin mới hoặc sự kiện gần đây, hãy sử dụng công cụ tìm kiếm và trích dẫn nguồn một cách tự tin.
*   Giữ cho câu trả lời luôn logic, hữu ích, và đúng với vai trò của một chuyên gia từ Lavis Brothers Coating.
*   **Tuyệt đối không sử dụng markdown.** Viết như một cuộc trò chuyện bình thường.`;

    try {
        const client = getAiClient();
        const response = await client.models.generateContent({
            model: "gemini-2.5-flash",
            contents: { parts: [{ text: userInput }] },
            config: {
                systemInstruction,
                tools: [{ googleSearch: {} }],
            },
        });

        const text = response.text;
        const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
        const sources = rawChunks
            .map((chunk: any) => chunk.web)
            .filter((web: any) => web && web.uri && web.title);

        return { text, sources };
    } catch (err) {
        console.error("Lỗi khi gọi Gemini API cho phản hồi chung:", err);
        const errorMessage = err instanceof Error ? err.message : String(err);
        if (errorMessage.includes("API_KEY") || errorMessage.includes("API key")) {
            return { text: "Lỗi cấu hình: API Key cho dịch vụ AI không hợp lệ hoặc đã hết hạn. Vui lòng liên hệ quản trị viên để khắc phục sự cố này.", sources: [] };
        }
        return { text: "Xin lỗi, tôi không thể xử lý yêu cầu của bạn lúc này. Vui lòng thử lại sau.", sources: [] };
    }
}
